import sqlite3
import smtplib
from email.message import EmailMessage
from fpdf import FPDF
import pandas as pd
from datetime import datetime
import io
from geopy.geocoders import Nominatim

DB_NAME = 'database.db'

# --- Database Migration Helper ---
def migrate_db_add_columns():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("PRAGMA table_info(bookings);")
    columns = [col[1] for col in c.fetchall()]

    new_columns = {
        "start_time": "TEXT",
        "end_time": "TEXT",
        "organization": "TEXT",
        "created_at": "TEXT"
    }

    for col, col_type in new_columns.items():
        if col not in columns:
            c.execute(f"ALTER TABLE bookings ADD COLUMN {col} {col_type};")

    conn.commit()
    conn.close()

# --- Database Initialization ---
def initialize_db():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (
        name TEXT,
        email TEXT PRIMARY KEY,
        password TEXT
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS bookings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_email TEXT,
        event_name TEXT,
        event_type TEXT,
        host_name TEXT,
        guest_name TEXT,
        phone TEXT,
        location TEXT,
        date TEXT,
        start_time TEXT,
        end_time TEXT,
        organization TEXT,
        status TEXT,
        created_at TEXT
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS unavailable_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_email TEXT,
        location TEXT,
        date TEXT,
        time TEXT,
        attempt_time TEXT
    )''')
    conn.commit()
    conn.close()
    migrate_db_add_columns()

# --- User Management ---
def create_user(name, email, password):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    try:
        c.execute("INSERT INTO users VALUES (?, ?, ?)", (name, email, password))
        conn.commit()
        return True
    except sqlite3.IntegrityError:
        return False
    finally:
        conn.close()

def get_user(email, password):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE email=? AND password=?", (email, password))
    user = c.fetchone()
    conn.close()
    return user

# --- Booking Management ---
def save_booking(data):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("""
        INSERT INTO bookings (
            user_email, event_name, event_type, host_name, guest_name,
            phone, location, date, start_time, end_time,
            organization, status, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        data["user_email"],
        data["event_name"],
        data["event_type"],
        data["host_name"],
        data["guest_name"],
        data["phone"],
        data["location"],
        data["date"],
        data["start_time"],
        data["end_time"],
        data["organization"],
        data.get("status", "Pending"),
        datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ))
    conn.commit()
    conn.close()

def get_pending_requests():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("""
        SELECT id, user_email, event_name, event_type, host_name,
               guest_name, phone, location, date, start_time, end_time, status
        FROM bookings
        WHERE status = 'Pending'
    """)
    results = c.fetchall()
    conn.close()
    return results

def update_booking_status(booking_id, status):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("UPDATE bookings SET status = ? WHERE id = ?", (status, booking_id))
    conn.commit()
    conn.close()

def get_user_bookings(email):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT * FROM bookings WHERE user_email = ? AND status = 'Approved'", (email,))
    results = c.fetchall()
    conn.close()
    return results

# --- Room Availability Check ---
def is_room_available(location, date, start_time, end_time):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("""
        SELECT * FROM bookings
        WHERE location = ?
        AND date = ?
        AND status = 'Approved'
        AND (
            (start_time < ? AND end_time > ?)
            OR (start_time >= ? AND start_time < ?)
        )
    """, (location, date, end_time, start_time, start_time, end_time))
    booked = c.fetchone()
    conn.close()
    return booked is None

# --- Log Unavailable Booking Attempt ---
def log_unavailable_booking(user_email, location, date, time):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    attempt_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    c.execute("""
        INSERT INTO unavailable_requests (user_email, location, date, time, attempt_time)
        VALUES (?, ?, ?, ?, ?)
    """, (user_email, location, date, time, attempt_time))
    conn.commit()
    conn.close()

# --- Location to Address Conversion ---
def get_address_from_location(location_name):
    try:
        geolocator = Nominatim(user_agent="room_scheduler_app")
        location = geolocator.geocode(location_name)
        return location.address if location else "Address not found"
    except Exception:
        return "Address lookup failed"

# --- Email Notification ---
def send_email(to_email, subject, message):
    try:
        email = EmailMessage()
        email.set_content(message)
        email['Subject'] = subject
        email['From'] = "youremail@example.com"
        email['To'] = to_email

        with smtplib.SMTP('smtp.gmail.com', 587) as smtp:
            smtp.starttls()
            smtp.login("jaanjanani.13@gmail.com", "qqea ahul nhlb fmcp")
            smtp.send_message(email)
    except Exception as e:
        print("Email failed:", e)

# --- Booking Approval Email ---
def send_booking_approval_email(to_email, name, event_name, location, date, start_time, end_time):
    subject = "Booking Approved"
    message = f"""
Dear {name},

Your booking request for the event '{event_name}' at location '{location}' on {date} from {start_time} to {end_time} has been approved.

Thank you for using our booking system.

Best regards,
Room Scheduler Team
"""
    send_email(to_email, subject, message)

# --- Booking Rejection Email ---
def send_booking_rejection_email(to_email, name, event_name, location, date, start_time, end_time):
    subject = "Booking Rejected"
    message = f"""
Dear {name},

We regret to inform you that your booking request for the event '{event_name}' at location '{location}' on {date} from {start_time} to {end_time} has been rejected.

Please contact admin for further information.

Best regards,
Room Scheduler Team
"""
    send_email(to_email, subject, message)

# --- Monthly PDF Report Generation ---
def generate_monthly_report():
    conn = sqlite3.connect(DB_NAME)
    query = """
        SELECT b.*, u.name as user_name
        FROM bookings b
        LEFT JOIN users u ON b.user_email = u.email
    """
    df = pd.read_sql_query(query, conn)
    df_unavailable = pd.read_sql_query("SELECT * FROM unavailable_requests", conn)
    df_unavailable['date'] = pd.to_datetime(df_unavailable['date'], errors='coerce')
    current_month = datetime.now().strftime("%Y-%m")
    unavailable_count = df_unavailable[df_unavailable['date'].dt.strftime('%Y-%m') == current_month].shape[0]
    conn.close()

    df['date'] = pd.to_datetime(df['date'], errors='coerce')
    df = df[df['date'].dt.strftime('%Y-%m') == current_month]
    df = df.sort_values(by='date')

    approved_count = df[df['status'] == 'Approved'].shape[0]
    rejected_count = df[df['status'] == 'Rejected'].shape[0]

    month_str = datetime.now().strftime('%B %Y')
    pdf = FPDF()
    pdf.set_auto_page_break(auto=False, margin=15)
    pdf.add_page()
    pdf.set_font("Times", 'B', 14)
    pdf.cell(200, 10, txt=f"Monthly Booking Report - {month_str}", ln=1, align='C')
    pdf.ln(10)

    if df.empty:
        pdf.set_font("Times", size=12)
        pdf.cell(0, 10, txt="No bookings for this month.", ln=1)
    else:
        for status in ['Approved', 'Pending', 'Rejected']:
            df_status = df[df['status'] == status]
            if not df_status.empty:
                pdf.set_font("Times", 'B', 12)
                pdf.cell(0, 10, txt=f"{status} Bookings", ln=1)
                pdf.set_font("Times", size=11)
                pdf.ln(2)

                for _, row in df_status.iterrows():
                    # Estimate vertical space needed per booking block
                    estimated_height = 8 * 7 + 5  # 7 lines + spacing

                    if pdf.get_y() + estimated_height > 280:
                        pdf.add_page()

                    status_icon = {
                        'Approved': '[APPROVED]',
                        'Pending': '[PENDING]',
                        'Rejected': '[REJECTED]'
                    }.get(row['status'], '')

                    pdf.cell(0, 8, txt=f"User: {row['user_name']} ({row['user_email']})", ln=1)
                    pdf.cell(0, 8, txt=f"Date: {row['date'].strftime('%Y-%m-%d')}, Time: {row['start_time']} - {row['end_time']}", ln=1)
                    pdf.cell(0, 8, txt=f"Event Name: {row['event_name']} ({row['event_type']})", ln=1)
                    pdf.cell(0, 8, txt=f"Host: {row['host_name']}, Guest: {row['guest_name']}", ln=1)
                    pdf.cell(0, 8, txt=f"Organization: {row['organization']}", ln=1)
                    pdf.cell(0, 8, txt=f"Location: {row['location']}, Contact: {row['phone']}", ln=1)
                    pdf.cell(0, 8, txt=f"Status: {status_icon}", ln=1)
                    pdf.ln(5)

        # Final Summary
        if pdf.get_y() + 30 > 280:
            pdf.add_page()

        pdf.ln(10)
        pdf.set_font("Times", 'B', 12)
        pdf.cell(0, 10, txt="Booking Summary", ln=1)
        pdf.set_font("Times", size=11)
        pdf.cell(0, 8, txt=f"Total Approved Bookings: {approved_count}", ln=1)
        pdf.cell(0, 8, txt=f"Total Rejected Bookings: {rejected_count}", ln=1)
        pdf.cell(0, 8, txt=f"Total Unavailable Slot Requests: {unavailable_count}", ln=1)

    pdf_buffer = io.BytesIO()
    pdf.output(pdf_buffer)
    pdf_buffer.seek(0)
    return pdf_buffer.read(), month_str



# --- Email Report to Admin ---
def send_report_to_admin():
    pdf_bytes, month_str = generate_monthly_report()
    email = EmailMessage()
    email['Subject'] = f"Monthly Room Booking Report - {month_str}"
    email['From'] = "youremail@example.com"
    email['To'] = "jaanjanani.13@gmail.com"
    email.set_content(f"Hi Admin,\n\nPlease find attached the monthly booking report for {month_str}.\n\nRegards,\nRoom Scheduler System")

    email.add_attachment(
        pdf_bytes,
        maintype='application',
        subtype='pdf',
        filename=f"Monthly_Booking_Report_{month_str.replace(' ', '_')}.pdf"
    )

    try:
        with smtplib.SMTP('smtp.gmail.com', 587) as smtp:
            smtp.starttls()
            smtp.login("jaanjanani.13@gmail.com", "qqea ahul nhlb fmcp")
            smtp.send_message(email)
            print("Report sent to admin successfully.")
    except Exception as e:
        print("Failed to send report:", e)
