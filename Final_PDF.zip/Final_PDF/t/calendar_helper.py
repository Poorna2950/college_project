import streamlit as st
import pandas as pd
import sqlite3
import calendar
from datetime import datetime

def display_calendar(user_email):
    conn = sqlite3.connect("database.db")
    query = "SELECT event_name, date FROM bookings WHERE user_email = ? AND status = 'Approved'"
    df = pd.read_sql_query(query, conn, params=(user_email,))
    conn.close()

    if df.empty:
        st.sidebar.info("No approved bookings found.")
    else:
        df['date'] = pd.to_datetime(df['date'])
        df.sort_values('date', inplace=True)
        for _, row in df.iterrows():
            event = row['event_name']
            date_str = row['date'].strftime("%b %d, %Y")
            st.sidebar.write(f"✅ **{event}** on {date_str}")
