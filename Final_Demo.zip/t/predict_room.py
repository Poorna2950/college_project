import pandas as pd
import joblib
from model_definition import load_model, preprocess_input

# Load the trained model and encoders
df_model, location_encoder, event_type_encoder, occupied_encoder = load_model()


def predict_locations(search_query, data):
    """
    Returns rows from 'data' whose 'Location' matches the search query text.
    """
    locations = data['Location'].unique()
    filtered = [loc for loc in locations if search_query.lower() in loc.lower()]
    if filtered:
        return data[data['Location'].isin(filtered)]
    return pd.DataFrame()


def predict_from_features(input_df):
    """
    input_df: DataFrame with features:
      'Room Capacity', 'Start Time', 'Weekday', 'Duration',
      'Attendees', 'Event Type', 'Is Occupied', 'Date'

    Returns: list of predicted location names
    """
    processed = preprocess_input(input_df.copy(), event_type_encoder, occupied_encoder)
    encoded_preds = df_model.predict(processed)
    return location_encoder.inverse_transform(encoded_preds)


def get_max_attendees_from_csv(location, min_capacity=50, csv_path="room_scheduling_data.csv"):
    """
    Returns the maximum 'Attendees' recorded in the CSV for events at 'location'
    where 'Room Capacity' >= min_capacity (i.e., "large" rooms).

    Args:
      location (str): room location to filter
      min_capacity (int): threshold to consider a room "large"
      csv_path (str): path to CSV file

    Returns:
      int or "N/A": max attendees or "N/A" if no matching records
    """
    df = pd.read_csv(csv_path)
    mask = (df['Location'] == location) & (df['Room Capacity'] >= min_capacity)
    subset = df.loc[mask, 'Attendees']
    if subset.empty:
        return "N/A"
    return int(subset.max())


def is_slot_available(location, date, time):
    """
    Checks if 'location' is free on 'date' at 'time'.
    Returns True if no booking exists for that slot, else False.
    """
    try:
        bookings = pd.read_csv("room_scheduling.csv")
    except FileNotFoundError:
        return True
    conflict = bookings[
        (bookings['Location'] == location) &
        (bookings['Date'] == date) &
        (bookings['Time'] == time)
    ]
    return conflict.empty
