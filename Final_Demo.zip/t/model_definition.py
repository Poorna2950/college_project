import pandas as pd
import joblib
import os
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder

MODEL_PATH = "trained_model.pkl"
LOCATION_ENCODER_PATH = "location_encoder.pkl"
EVENT_TYPE_ENCODER_PATH = "event_type_encoder.pkl"
OCCUPIED_ENCODER_PATH = "occupied_encoder.pkl"

def train_model():
    # Load data
    df = pd.read_csv("room_scheduling_data.csv")

    # Preprocess time and date columns
    df['Start Time'] = pd.to_datetime(df['Start Time']).dt.hour
    df['Date'] = pd.to_datetime(df['Date']).map(pd.Timestamp.toordinal)

    # Convert categorical columns to strings (in case)
    df['Event Type'] = df['Event Type'].astype(str)
    df['Is Occupied'] = df['Is Occupied'].astype(str)

    # Features and target
    feature_cols = ['Room Capacity', 'Start Time', 'Weekday', 'Duration', 'Attendees', 'Event Type', 'Is Occupied', 'Date']
    X = df[feature_cols]
    y = df['Location']

    # Encode categorical features
    event_type_encoder = LabelEncoder()
    X['Event Type'] = event_type_encoder.fit_transform(X['Event Type'])

    occupied_encoder = LabelEncoder()
    X['Is Occupied'] = occupied_encoder.fit_transform(X['Is Occupied'])

    # Encode target variable (Location)
    location_encoder = LabelEncoder()
    y_encoded = location_encoder.fit_transform(y)

    # Train Random Forest model
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X, y_encoded)

    # Save model and encoders
    joblib.dump(model, MODEL_PATH)
    joblib.dump(location_encoder, LOCATION_ENCODER_PATH)
    joblib.dump(event_type_encoder, EVENT_TYPE_ENCODER_PATH)
    joblib.dump(occupied_encoder, OCCUPIED_ENCODER_PATH)

def load_model():
    # Train if model or encoders do not exist
    if not (os.path.exists(MODEL_PATH) and os.path.exists(LOCATION_ENCODER_PATH)
            and os.path.exists(EVENT_TYPE_ENCODER_PATH) and os.path.exists(OCCUPIED_ENCODER_PATH)):
        train_model()

    model = joblib.load(MODEL_PATH)
    location_encoder = joblib.load(LOCATION_ENCODER_PATH)
    event_type_encoder = joblib.load(EVENT_TYPE_ENCODER_PATH)
    occupied_encoder = joblib.load(OCCUPIED_ENCODER_PATH)
    return model, location_encoder, event_type_encoder, occupied_encoder

# Optional: a helper function for prediction input preprocessing
def preprocess_input(input_df, event_type_encoder, occupied_encoder):
    # Convert Start Time and Date same way as training
    input_df['Start Time'] = pd.to_datetime(input_df['Start Time']).dt.hour
    input_df['Date'] = pd.to_datetime(input_df['Date']).map(pd.Timestamp.toordinal)

    # Encode categorical features
    input_df['Event Type'] = event_type_encoder.transform(input_df['Event Type'].astype(str))
    input_df['Is Occupied'] = occupied_encoder.transform(input_df['Is Occupied'].astype(str))

    return input_df
