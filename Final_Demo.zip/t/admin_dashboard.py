import streamlit as st
from utils import (
    get_pending_requests,
    update_booking_status,
    send_booking_approval_email,
    send_booking_rejection_email,
    generate_monthly_report,
    send_report_to_admin
)

def main():
    st.title("👨‍💼 Admin Dashboard")

    # ---------- Pending Booking Requests ----------
    pending = get_pending_requests()
    st.markdown(f"### 🔔 Pending Requests ({len(pending)})")

    if pending:
        for booking in pending:
            # Unpack all booking fields; adjust according to actual schema
            # Expected booking tuple:
            # (id, user_email, event_name, event_type, host_name, guest_name, phone, location, date, start_time, end_time, status)
            booking_id, user_email, event_name, event_type, host_name, guest_name, phone, location, date, start_time, end_time, status, created_at = booking
            with st.expander(f"📌 Request #{booking_id}: {event_name} | {date} {start_time}-{end_time}"):
                st.markdown(f"""
                    - **User Email:** `{user_email}`
                    - **Phone:** `{phone}`
                    - **Event Type:** {event_type}
                    - **Host Name:** {host_name}
                    - **Guest Name:** {guest_name}
                    - **Location:** 📍 {location}
                    - **Date & Time:** 🗓 {date} ⏰ {start_time} to {end_time}
                    - **Status:** 🟡 {status}
                """)

                col1, col2 = st.columns(2)
                with col1:
                    if st.button(f"✅ Approve #{booking_id}", key=f"approve_{booking_id}"):
                        update_booking_status(booking_id, "Approved")
                        send_booking_approval_email(
                            to_email=user_email,
                            name=user_email,
                            event_name=event_name,
                            location=location,
                            date=date,
                            start_time=start_time,
                            end_time=end_time
                        )
                        st.success("Booking approved and confirmation email sent.")
                        st.rerun()

                with col2:
                    if st.button(f"❌ Reject #{booking_id}", key=f"reject_{booking_id}"):
                        update_booking_status(booking_id, "Rejected")
                        send_booking_rejection_email(
                            to_email=user_email,
                            name=user_email,
                            event_name=event_name,
                            location=location,
                            date=date,
                            start_time=start_time,
                            end_time=end_time
                        )
                        st.warning("Booking rejected and notification sent.")
                        st.rerun()
    else:
        st.info("✅ No pending requests at the moment.")

    # ---------- Monthly Report Section ----------
    st.markdown("---")
    st.subheader("📄 Monthly Booking Report")

    pdf_bytes, report_month = generate_monthly_report()

    st.download_button(
        label="📅 Download Report as PDF",
        data=pdf_bytes,
        file_name=f"monthly_report_{report_month.replace(' ', '_')}.pdf",
        mime="application/pdf"
    )

    if st.button("📧 Email Report to Admin"):
        send_report_to_admin()
        st.success("✅ Monthly report emailed to admin.")

if __name__ == "__main__":
    main()
