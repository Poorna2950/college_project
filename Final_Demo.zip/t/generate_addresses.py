import pandas as pd
from geopy.geocoders import Nominatim
from geopy.exc import GeocoderTimedOut, GeocoderUnavailable
import time

def get_address(location_name, retries=3):
    geolocator = Nominatim(user_agent="room_scheduler")
    for _ in range(retries):
        try:
            location = geolocator.geocode(location_name + ", Bangalore")
            if location:
                return location.address
            else:
                return "Address not found"
        except (GeocoderTimedOut, GeocoderUnavailable):
            time.sleep(1)
    return "Geocoding service unavailable"

def main():
    try:
        df = pd.read_csv("room_scheduling_data.csv")
    except FileNotFoundError:
        print("❌ Error: 'room_scheduling_data.csv' not found in the current directory.")
        return

    unique_locations = df['Location'].dropna().unique()
    
    address_list = []

    for loc in unique_locations:
        print(f"📍 Fetching address for: {loc}")
        address = get_address(loc)
        address_list.append({'Location': loc, 'Address': address})
        time.sleep(1)  # to respect Nominatim rate limits

    address_df = pd.DataFrame(address_list)
    address_df.to_csv("location_addresses.csv", index=False)
    print("✅ All addresses saved to 'location_addresses.csv'")

if __name__ == "__main__":
    main()
