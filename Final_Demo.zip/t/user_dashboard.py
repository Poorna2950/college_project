import streamlit as st
import pandas as pd
import os
from predict_room import predict_locations, get_max_attendees_from_csv
from calendar_helper import display_calendar
from PIL import Image

# Your CSS with flashcard styles here
page_bg = """
<style>
[data-testid="stAppViewContainer"] {
    background-image: url("https://images.unsplash.com/photo-1633113210508-938a5f8bb9ae?auto=format&fit=crop&w=1400&q=80");
    background-size: cover;
    background-position: center;
}
.block-container {
    background-color: rgba(0, 0, 0, 0.5) !important;
    border-radius: 10px;
    padding: 2rem;
}

.flashcard {
    background-color: rgba(255, 255, 255, 0.95);
    border-radius: 16px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
    padding: 1rem;
    margin-bottom: 1.5rem;
    text-align: center;
    transition: transform 0.2s ease;
    cursor: default;
}

.flashcard:hover {
    transform: scale(1.03);
}

.flashcard h4 {
    color: #4a148c;
    margin: 0.5rem 0 0.2rem;
    font-weight: bold;
}

.flashcard p, .flashcard small {
    color: #333;
    margin-bottom: 0.3rem;
    font-size: 0.9rem;
}

.stButton > button {
    background-color: #7e57c2;
    color: white;
    border: none;
    padding: 0.4rem 0.9rem;
    border-radius: 8px;
    font-weight: bold;
    transition: background 0.3s ease;
    margin-top: 0.5rem;
    width: 100%;
}

.stButton > button:hover {
    background-color: #5e35b1;
}
</style>
"""

st.markdown(page_bg, unsafe_allow_html=True)

if "page" not in st.session_state:
    st.session_state.page = "user_dashboard"

if st.session_state.page == "booking_form":
    from user_booking_form import booking_form_page
    booking_form_page()
    st.stop()

@st.cache_data
def load_address_map():
    try:
        df = pd.read_csv("location_addresses.csv")
        return dict(zip(df['Location'], df['Address']))
    except Exception as e:
        st.warning("Could not load addresses: " + str(e))
        return {}

def main():
    st.markdown(
        "<h2 style='color: #d4af37; font-weight: 800; "
        "text-shadow: 1px 1px 2px #b8860b;'>Welcome to Conference Room Scheduler</h2>",
        unsafe_allow_html=True,
    )

    st.sidebar.title("Your Bookings")
    if "user_email" in st.session_state:
        display_calendar(st.session_state.user_email)
    else:
        st.sidebar.warning("Login required to view bookings.")

    data = pd.read_csv("room_scheduling_data.csv")
    room_images_dir = "room_images"
    address_map = load_address_map()

    search_key = f"search_loc_{st.session_state.get('user_email', '')}"
    search = st.text_input("Search Location", key=search_key)

    predicted = predict_locations(search, data) if search else data
    predicted = predicted.drop_duplicates(subset='Location').reset_index(drop=True)

    st.subheader("Available Conference Rooms")

    cols = st.columns(2)  # 2 columns per row
    for idx, row in predicted.iterrows():
        location = row['Location']
        location_folder = os.path.join(room_images_dir, location)
        image_path = None
        for ext in ["jpeg", "jpg", "png"]:
            candidate = os.path.join(location_folder, f"Image1.{ext}")
            if os.path.exists(candidate):
                image_path = candidate
                break

        address = address_map.get(location, "Address not found")
        max_attended = get_max_attendees_from_csv(location)

        with cols[idx % 2]:
            if image_path:
                img = Image.open(image_path)
                img = img.resize((300, 200), Image.Resampling.LANCZOS)
                st.image(img, use_container_width=True)
            else:
                st.image("https://via.placeholder.com/300x200?text=No+Image", use_column_width=True)

            st.markdown(
                f"""
                <div class="flashcard">
                    <h4>{location}</h4>
                    <p><strong>Address:</strong> {address}</p>
                    <small><strong>Max Attendees:</strong> {max_attended}</small>
                </div>
                """,
                unsafe_allow_html=True
            )

            if st.button("View Details", key=f"view_{idx}"):
                st.session_state.selected_room = row.to_dict()
                st.session_state.selected_room["Address"] = address
                st.session_state.page = "booking_form"
                st.rerun()

if __name__ == "__main__":
    main()
