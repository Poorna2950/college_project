import streamlit as st

# ✅ Set page config - must be the first Streamlit command
st.set_page_config(page_title="Automated Conference Room Scheduling", page_icon="📅", layout="wide")

# ✅ Continue with other imports
import re
import sqlite3
from utils import initialize_db, get_user, create_user
from user_booking_form import booking_form_page
from user_dashboard import main as user_dashboard_main
from admin_dashboard import main as admin_dashboard_main

# ✅ Custom CSS with bigger font sizes
page_bg = """
<style>
html, body, [data-testid="stAppViewContainer"] {
    padding: 0 !important;
    margin: 0 !important;
    background: linear-gradient(135deg, #e0f7fa 0%, #fce4ec 100%) !important;
    background-size: cover !important;
    font-family: 'Segoe UI', sans-serif !important;
    font-size: 18px !important;
}

/* Remove white box */
section.main > div {
    background: transparent !important;
    box-shadow: none !important;
}

/* Hero Banner */
.hero-banner {
    text-align: center;
    padding: 1rem 1rem 0.5rem 1rem;
}

.hero-banner h1 {
    font-size: 3rem;
    font-weight: bold;
    margin-bottom: 0.5rem;
    color: #4a148c;
}

.hero-banner p {
    font-size: 1.3rem;
    color: #555;
}

/* Login Card */
.login-card {
    max-width: 500px;
    margin: 0 auto;
    padding: 1.5rem;
    border-radius: 16px;
    background: rgba(255, 255, 255, 0.0);
    margin-top: -1rem;
}

/* Inputs */
input, .stTextInput input {
    background-color: #f9f9f9 !important;
    color: #000 !important;
    border-radius: 6px;
    padding: 0.75rem;
    border: 1px solid #ccc;
    font-size: 1.1rem;
}

/* Text and Labels */
h2, label, .stRadio label {
    color: #222;
    font-weight: 600;
    font-size: 1.1rem;
}

.stTextInput > label {
    font-weight: 600;
    color: #333;
    font-size: 1.1rem;
}

/* Buttons */
.stButton > button {
    background-color: #64b5f6;
    background-image: linear-gradient(to right, #ba68c8, #64b5f6);
    color: white;
    padding: 0.7rem 2rem;
    border: none;
    border-radius: 8px;
    font-weight: 600;
    font-size: 1.1rem;
    margin-top: 1rem;
}

.stButton > button:hover {
    background-image: linear-gradient(to right, #64b5f6, #ba68c8);
    transform: scale(1.03);
    transition: all 0.2s ease;
}

/* Radio buttons */
.css-1c7y2kd {
    display: flex !important;
    flex-direction: row !important;
    justify-content: center !important;
    gap: 2rem !important;
    margin-bottom: 0.5rem !important;
}
</style>
"""
st.markdown(page_bg, unsafe_allow_html=True)

# ✅ Initialize DB
initialize_db()

# ✅ Session State
if "login_state" not in st.session_state:
    st.session_state.login_state = False
if "page" not in st.session_state:
    st.session_state.page = None

# ✅ Redirect if already logged in
if st.session_state.login_state:
    current_page = st.session_state.get("page")
    if current_page == "user_dashboard":
        user_dashboard_main()
        st.stop()
    elif current_page == "admin_dashboard":
        admin_dashboard_main()
        st.stop()
    elif current_page == "booking_form":
        booking_form_page()
        st.stop()

# ✅ Hero Banner
st.markdown("""
<div class="hero-banner">
    <h1>📅 Automated Conference Room Scheduling</h1>
    <p>Book smart. Meet smarter. Seamless scheduling at your fingertips.</p>
</div>
""", unsafe_allow_html=True)

# ✅ Mode Selector
mode = st.radio("Select Mode", ["User Login", "Admin Login", "Signup"], horizontal=False)

# ✅ Login/Signup Form
st.markdown('<div class="login-card">', unsafe_allow_html=True)

if mode == "Signup":
    st.subheader("Create a new account")
    name = st.text_input("Name")
    email = st.text_input("Email")
    pwd = st.text_input("Password", type="password")
    pwd2 = st.text_input("Confirm Password", type="password")

    if st.button("Sign Up"):
        if not name or not email or not pwd or not pwd2:
            st.error("Please fill all fields.")
        elif pwd != pwd2:
            st.error("Passwords do not match.")
        elif not re.match(r"[^@]+@[^@]+\.[^@]+", email):
            st.error("Invalid email format.")
        else:
            success = create_user(name, email, pwd)
            if success:
                st.success("Account created! Please login.")
            else:
                st.error("Account already exists.")

elif mode == "User Login":
    st.subheader("User Login")
    email = st.text_input("Email")
    pwd = st.text_input("Password", type="password")

    if st.button("Login"):
        if not email or not pwd:
            st.error("Please enter email and password.")
        else:
            user = get_user(email, pwd)
            if user:
                st.session_state.login_state = True
                st.session_state.user_email = email
                st.session_state.user_name = user[0]
                st.session_state.page = "user_dashboard"
                st.rerun()
            else:
                st.error("Invalid credentials or account not found.")

else:  # Admin Login
    st.subheader("Admin Login")
    email = st.text_input("Admin Email")
    pwd = st.text_input("Password", type="password")

    if st.button("Login"):
        if email == 'jaanjanani.13@gmail.com' and pwd == 'admin':
            st.session_state.login_state = True
            st.session_state.user_email = email
            st.session_state.user_name = "Admin"
            st.session_state.page = "admin_dashboard"
            st.rerun()
        else:
            st.error("Invalid admin credentials.")

st.markdown('</div>', unsafe_allow_html=True)
