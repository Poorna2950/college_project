import streamlit as st
import time
from PIL import Image
from utils import save_booking

def payment_page():
    st.markdown("<h2 style='color:white;'>🔐 Payment Page</h2>", unsafe_allow_html=True)

    # ---- Display Scanner Image ----
    st.markdown("### Scan to Pay")
    scanner_image_path = "Scanner_Image.jpeg"  # Relative path for portability

    try:
        scanner_img = Image.open(scanner_image_path)
        st.image(scanner_img, caption="Scan using any UPI App", use_container_width=False)
    except:
        st.warning("⚠️ Scanner image not found. Please ensure 'Scanner_Image.jpeg' is in the project directory.")

    st.info("💡 You can also complete the payment By Scan and Pay.")

    # ---- Confirm Booking Button ----
    if st.button("✅ Confirm Booking"):
        if "booking_details" in st.session_state:
            booking_data = st.session_state.booking_details

            # Set booking status to "Pending"
            booking_data["status"] = "Pending"

            # Save to database
            save_booking(booking_data)

            st.success("✅ Booking Request Sent, Waiting for Admin Approval")
            time.sleep(5)

            # Clean up and redirect
            st.session_state.page = "user_dashboard"
            del st.session_state.booking_details
            st.rerun()
        else:
            st.error("⚠️ Booking information missing. Please return to the booking form and try again.")

    # ---- Back Button ----
    if st.button("← Back"):
        st.session_state.page = "user_booking_form"
        st.rerun()
