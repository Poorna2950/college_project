import streamlit as st
import os
import glob
import re
from utils import save_booking, is_room_available
from PIL import Image
from datetime import datetime, date, timedelta
import sqlite3
import time
import user_dashboard
from utils import log_unavailable_booking

def booking_form_page():
    room = st.session_state.get("selected_room", {})
    if not room:
        st.warning("⚠️ No room selected.")
        return

    st.markdown(
        f"<h2 style='color: white;'>Booking Form - <span style='color:#d4af37;'>{room['Location']}</span></h2>",
        unsafe_allow_html=True
    )

    st.caption(room.get('Address', 'No address available'))

    room_images_dir = "room_images"
    detailed_folder = os.path.join(room_images_dir, room['Location'])

    image_files = sorted(
        glob.glob(os.path.join(detailed_folder, "Image*.jpeg")) +
        glob.glob(os.path.join(detailed_folder, "Image*.jpg")) +
        glob.glob(os.path.join(detailed_folder, "Image*.png"))
    )

    if image_files:
        img_placeholder = st.empty()
        for img_path in image_files:
            img_placeholder.image(img_path, use_container_width=True)
            time.sleep(5)
    else:
        st.warning("🚫 No images available for this room.")

    st.markdown("---")
    st.markdown("### :memo: Fill Your Booking Details")

    with st.form("booking_form"):
        name = st.text_input("Your Name", value=st.session_state.get("user_name", ""))
        email = st.text_input("Email", value=st.session_state.get("user_email", ""))
        phone = st.text_input("Phone Number")
        event_name = st.text_input("Event Name")
        event_type = st.selectbox("Event Type", ["Seminar", "Conference", "Meetings", "Workshop"])
        organization = st.selectbox("Organization Type", ["Private", "Public", "Academic", "Startup", "Other"])
        host_name = st.text_input("Host Name")
        guest_name = st.text_input("Guest Name")
        date_selected = st.date_input("Event Date", min_value=date.today() + timedelta(days=1))
        start_time = st.time_input("Start Time")
        end_time = st.time_input("End Time")

        clicked_pay = st.form_submit_button("Click to Pay")

        if clicked_pay:
            if not all([name, email, phone, event_name, host_name, guest_name]):
                st.error("⚠️ Please fill all required fields.")
            elif not re.match(r'^\S+@\S+\.\S+$', email):
                st.error("📧 Invalid email format.")
            elif not (phone.isdigit() and len(phone) == 10):
                st.error("📱 Phone number must be exactly 10 digits.")
            elif start_time >= end_time:
                st.error("⏰ Start time must be before end time.")
            else:
                st.info("🔍 Checking room availability...")
                available = is_room_available(
                    room['Location'],
                    date_selected.strftime("%Y-%m-%d"),
                    start_time.strftime("%H:%M"),
                    end_time.strftime("%H:%M")
                )

                if not available:
                    st.error("❌ At this Date and Timings the slot is not Available")

                    # ✅ Define missing variables
                    location = room['Location']
                    date = date_selected.strftime("%Y-%m-%d")
                    time = start_time.strftime("%H:%M")
                    attempt_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                    # ✅ Log the unavailable booking attempt
                    log_unavailable_booking(
                    email,
                    room['Location'],
                    date_selected.strftime("%Y-%m-%d"),
                    start_time.strftime("%H:%M"),
                    datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    )

                    


                else:
                    # ✅ Fix: Add 'user_email' explicitly for downstream use
                    st.session_state.booking_details = {
                        "user_email": email,
                        "email": email,
                        "event_name": event_name,
                        "event_type": event_type,
                        "host_name": host_name,
                        "guest_name": guest_name,
                        "phone": phone,
                        "location": room['Location'],
                        "date": date_selected.strftime("%Y-%m-%d"),
                        "start_time": start_time.strftime("%H:%M"),
                        "end_time": end_time.strftime("%H:%M"),
                        "organization": organization
                    }
                    st.session_state.page = "payment_page"
                    st.rerun()
        


    if st.button("← Back to Home"):
        st.session_state.page = "user_dashboard"
        st.rerun()
