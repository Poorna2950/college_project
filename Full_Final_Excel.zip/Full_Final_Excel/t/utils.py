import sqlite3
import smtplib
from email.message import EmailMessage
import pandas as pd
from datetime import datetime
import io
from geopy.geocoders import Nominatim

DB_NAME = 'database.db'

# --- Database Migration Helper ---
def migrate_db_add_columns():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("PRAGMA table_info(bookings);")
    columns = [col[1] for col in c.fetchall()]

    new_columns = {
        "start_time": "TEXT",
        "end_time": "TEXT",
        "organization": "TEXT",
        "created_at": "TEXT"
    }

    for col, col_type in new_columns.items():
        if col not in columns:
            c.execute(f"ALTER TABLE bookings ADD COLUMN {col} {col_type};")

    conn.commit()
    conn.close()

# --- Database Initialization ---
def initialize_db():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (
        name TEXT,
        email TEXT PRIMARY KEY,
        password TEXT
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS bookings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_email TEXT,
        event_name TEXT,
        event_type TEXT,
        host_name TEXT,
        guest_name TEXT,
        phone TEXT,
        location TEXT,
        date TEXT,
        start_time TEXT,
        end_time TEXT,
        organization TEXT,
        status TEXT,
        created_at TEXT
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS unavailable_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_email TEXT,
        location TEXT,
        date TEXT,
        time TEXT,
        attempt_time TEXT
    )''')
    conn.commit()
    conn.close()
    migrate_db_add_columns()

# --- User Management ---
def create_user(name, email, password):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    try:
        c.execute("INSERT INTO users VALUES (?, ?, ?)", (name, email, password))
        conn.commit()
        return True
    except sqlite3.IntegrityError:
        return False
    finally:
        conn.close()

def get_user(email, password):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE email=? AND password=?", (email, password))
    user = c.fetchone()
    conn.close()
    return user

# --- Booking Management ---
def save_booking(data):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("""
        INSERT INTO bookings (
            user_email, event_name, event_type, host_name, guest_name,
            phone, location, date, start_time, end_time,
            organization, status, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        data["user_email"],
        data["event_name"],
        data["event_type"],
        data["host_name"],
        data["guest_name"],
        data["phone"],
        data["location"],
        data["date"],
        data["start_time"],
        data["end_time"],
        data["organization"],
        data.get("status", "Pending"),
        datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ))
    conn.commit()
    conn.close()

def get_pending_requests():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("""
        SELECT id, user_email, event_name, event_type, host_name,
               guest_name, phone, location, date, start_time, end_time, status
        FROM bookings
        WHERE status = 'Pending'
    """)
    results = c.fetchall()
    conn.close()
    return results

def update_booking_status(booking_id, status):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("UPDATE bookings SET status = ? WHERE id = ?", (status, booking_id))
    conn.commit()
    conn.close()

def get_user_bookings(email):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT * FROM bookings WHERE user_email = ? AND status = 'Approved'", (email,))
    results = c.fetchall()
    conn.close()
    return results

# --- Room Availability Check ---
def is_room_available(location, date, start_time, end_time):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("""
        SELECT * FROM bookings
        WHERE location = ?
        AND date = ?
        AND status = 'Approved'
        AND (
            (start_time < ? AND end_time > ?)
            OR (start_time >= ? AND start_time < ?)
        )
    """, (location, date, end_time, start_time, start_time, end_time))
    booked = c.fetchone()
    conn.close()
    return booked is None

# --- Log Unavailable Booking Attempt ---
def log_unavailable_booking(email, location, date, time, attempt_time):
    conn = sqlite3.connect("database.db")  # remove "t/" prefix
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS unavailable_requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_email TEXT,
            location TEXT,
            date TEXT,
            time TEXT,
            attempt_time TEXT
        )
    """)
    cursor.execute("""
        INSERT INTO unavailable_requests (user_email, location, date, time, attempt_time)
        VALUES (?, ?, ?, ?, ?)
    """, (email, location, date, time, attempt_time))
    conn.commit()
    conn.close()


# --- Location to Address Conversion ---
def get_address_from_location(location_name):
    try:
        geolocator = Nominatim(user_agent="room_scheduler_app")
        location = geolocator.geocode(location_name)
        return location.address if location else "Address not found"
    except Exception:
        return "Address lookup failed"

# --- Email Notification ---
def send_email(to_email, subject, message):
    try:
        email = EmailMessage()
        email.set_content(message)
        email['Subject'] = subject
        email['From'] = "youremail@example.com"
        email['To'] = to_email

        with smtplib.SMTP('smtp.gmail.com', 587) as smtp:
            smtp.starttls()
            smtp.login("jaanjanani.13@gmail.com", "qqea ahul nhlb fmcp")
            smtp.send_message(email)
    except Exception as e:
        print("Email failed:", e)

# --- Booking Approval Email ---
def send_booking_approval_email(to_email, name, event_name, location, date, start_time, end_time):
    subject = "Booking Approved"
    message = f"""
Dear {name},

Your booking request for the event '{event_name}' at location '{location}' on {date} from {start_time} to {end_time} has been approved.

Thank you for using our booking system.

Best regards,
Room Scheduler Team
"""
    send_email(to_email, subject, message)

# --- Booking Rejection Email ---
def send_booking_rejection_email(to_email, name, event_name, location, date, start_time, end_time):
    subject = "Booking Rejected"
    message = f"""
Dear {name},

We regret to inform you that your booking request for the event '{event_name}' at location '{location}' on {date} from {start_time} to {end_time} has been rejected.

Please contact admin for further information.

Best regards,
Room Scheduler Team
"""
    send_email(to_email, subject, message)

# --- Monthly PDF Report Generation ---
def generate_monthly_report_excel():
    conn = sqlite3.connect(DB_NAME)

    # Get bookings + user name
    query = """
        SELECT b.*, u.name as user_name
        FROM bookings b
        LEFT JOIN users u ON b.user_email = u.email
    """
    df_bookings = pd.read_sql_query(query, conn)

    # Read and rename unavailable requests
    df_unavailable = pd.read_sql_query("""
        SELECT user_email, location, date, time, attempt_time
        FROM unavailable_requests
    """, conn)

    # ✅ Reorder columns explicitly to ensure correct alignment
    df_unavailable = df_unavailable[['user_email', 'location', 'date', 'time', 'attempt_time']]

    # Ensure correct data types
    df_bookings['date'] = pd.to_datetime(df_bookings['date'], errors='coerce')
    df_unavailable['date'] = pd.to_datetime(df_unavailable['date'], errors='coerce')
    df_unavailable['attempt_time'] = pd.to_datetime(df_unavailable['attempt_time'], errors='coerce')

    df_bookings = df_bookings[df_bookings['date'].notna()]
    df_unavailable = df_unavailable[df_unavailable['date'].notna()]

    # Filter for current month
    current_month = datetime.now().strftime("%Y-%m")
    df_bookings = df_bookings[df_bookings['date'].dt.strftime('%Y-%m') == current_month]
    df_unavailable = df_unavailable[df_unavailable['date'].dt.strftime('%Y-%m') == current_month]

    # Format dates
    df_bookings['date'] = df_bookings['date'].dt.strftime('%Y-%m-%d')
    df_unavailable['date'] = df_unavailable['date'].dt.strftime('%Y-%m-%d')
    df_unavailable['attempt_time'] = df_unavailable['attempt_time'].dt.strftime('%Y-%m-%d %H:%M:%S')

    # Drop unnecessary columns from bookings
    columns_to_drop = ['id', 'time', 'organization', 'created_at']
    df_bookings = df_bookings.drop(columns=[col for col in columns_to_drop if col in df_bookings.columns])

    # Sort bookings
    df_bookings = df_bookings.sort_values(by='date')

    # Summary stats
    summary_df = pd.DataFrame({
        'Metric': ['Approved Bookings', 'Pending Bookings', 'Rejected Bookings', 'Unavailable Requests'],
        'Count': [
            df_bookings[df_bookings['status'] == 'Approved'].shape[0],
            df_bookings[df_bookings['status'] == 'Pending'].shape[0],
            df_bookings[df_bookings['status'] == 'Rejected'].shape[0],
            df_unavailable.shape[0]
        ]
    })

    # Save to Excel in memory
    buffer = io.BytesIO()
    with pd.ExcelWriter(buffer, engine='openpyxl') as writer:
        df_bookings.to_excel(writer, sheet_name='Bookings', index=False)
        summary_df.to_excel(writer, sheet_name='Summary', index=False)

    conn.close()
    buffer.seek(0)
    return buffer, datetime.now().strftime('%B %Y')


# --- Email Report to Admin ---
def send_report_to_admin():
    pdf_bytes, month_str = generate_monthly_report_excel()
    email = EmailMessage()
    email['Subject'] = f"Monthly Room Booking Report - {month_str}"
    email['From'] = "youremail@example.com"
    email['To'] = "jaanjanani.13@gmail.com"
    email.set_content(f"Hi Admin,\n\nPlease find attached the monthly booking report for {month_str}.\n\nRegards,\nRoom Scheduler System")

    email.add_attachment(
        pdf_bytes,
        maintype='application',
        subtype='pdf',
        filename=f"Monthly_Booking_Report_{month_str.replace(' ', '_')}.pdf"
    )

    try:
        with smtplib.SMTP('smtp.gmail.com', 587) as smtp:
            smtp.starttls()
            smtp.login("jaanjanani.13@gmail.com", "qqea ahul nhlb fmcp")
            smtp.send_message(email)
            print("Report sent to admin successfully.")
    except Exception as e:
        print("Failed to send report:", e)
